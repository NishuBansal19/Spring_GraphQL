package com.adobe.demo;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Component;

import graphql.ExceptionWhileDataFetching;
import graphql.GraphQLError;
import graphql.kickstart.execution.error.GenericGraphQLError;
import graphql.kickstart.execution.error.GraphQLErrorHandler;

@Component
public class CustomGraphQLErrorHandler implements GraphQLErrorHandler {
	public static <T> Stream<T> collectionStream(Collection<T> collection) {
		return collection == null || collection.isEmpty() ? Stream.empty() : collection.stream();
	}

	@Override
	public List<GraphQLError> processErrors(List<GraphQLError> errors) {
		return collectionStream(errors).map(this::unwrapError).collect(Collectors.toList());
	}

	private GraphQLError unwrapError(GraphQLError error) {
		if (error instanceof ExceptionWhileDataFetching) {
			ExceptionWhileDataFetching unwrappedError = (ExceptionWhileDataFetching) error;
			return new GenericGraphQLError(unwrappedError.getException().getMessage());
		} else {
			return error;
		}
	}
}
