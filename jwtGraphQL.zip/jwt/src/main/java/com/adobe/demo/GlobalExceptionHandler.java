package com.adobe.demo;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ExceptionHandler;

import graphql.GraphQLException;
import graphql.kickstart.spring.error.ThrowableGraphQLError;
import io.jsonwebtoken.SignatureException;

@Component
public class GlobalExceptionHandler {
	@ExceptionHandler({GraphQLException.class,BadTokenException.class} )
	public ThrowableGraphQLError handle(Exception ex) {
		System.out.println("------------>");
		return new ThrowableGraphQLError(ex);
	}
}
