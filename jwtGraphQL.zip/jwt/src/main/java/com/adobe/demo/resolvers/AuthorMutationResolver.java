package com.adobe.demo.resolvers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import com.adobe.demo.dao.AuthorDao;
import com.adobe.demo.entity.Author;

import graphql.kickstart.tools.GraphQLMutationResolver;

@Component
@Validated
public class AuthorMutationResolver implements GraphQLMutationResolver {
	@Autowired
	private AuthorDao authorDao;
	
	@Secured("ROLE_ADMIN")
	public Integer createAuthor(Author author) {
		return authorDao.save(author).getId();
	}
}
