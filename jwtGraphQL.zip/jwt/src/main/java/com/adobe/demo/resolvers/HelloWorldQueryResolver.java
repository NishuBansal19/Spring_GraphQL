package com.adobe.demo.resolvers;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import graphql.kickstart.tools.GraphQLQueryResolver;

@Component
public class HelloWorldQueryResolver implements GraphQLQueryResolver {
	//public String getHelloWorld() {
	@PreAuthorize("isAnonymous()")
	public String helloWorld() {
		return "Hello World GraphQL!!!";
	}
	@PreAuthorize("isAnonymous()")
	public String greeting(String firstName, String lastName) {
		return String.format("Hello %s %s ", firstName, lastName);
	}
}
